package turingMachine.io;

import finiteStateMachine.state.State;
import finiteStateMachine.state.Transition;
import turingMachine.TuringMachine;
import turingMachine.TuringTransitionOutput;
import turingMachine.tape.Direction;
import turingMachine.tape.MultiTape;
import turingMachine.tape.MultiTapeReadWriteData;
import turingMachine.tape.TapeChangeListener;

import java.io.*;

public class TuringMachineReader {


    public static TuringMachine<Character> read(InputStream input) {
        if (input == null)
            throw new IllegalArgumentException("");
        BufferedReader reader = new BufferedReader(new InputStreamReader(input));
        int cnt = 0;
        int tapeCount = 0;
        int index = 0;
        TuringMachine<Character> turingMachine = null;
        try {
            while (reader.ready()) {
                String line = reader.readLine();
                if (line == null)
                    break;
                if (line.isEmpty())
                    continue;
                if (line.trim().charAt(0) == '#')
                    continue;
                if (cnt == 0) {
                    tapeCount = Integer.parseInt(line.trim());
                    cnt++;
                    turingMachine = new TuringMachine<>(tapeCount);
                    for (int i = 0; i < tapeCount; i++) {
                        int finalI = i;
                        TuringMachine<Character> finalTuringMachine = turingMachine;
                        turingMachine.getTapes().getTapes().get(i).addListener(new TapeChangeListener<Character>() {
                            @Override
                            public void onMove(Direction direction) {

                            }

                            @Override
                            public void onExpand(Direction direction) {
                                if(direction.equals(Direction.RIGHT)) {
//                                    System.out.println("%%%%%%%%%%%%%");
                                    finalTuringMachine.getTapes().getTapes().get(finalI).write('_');
//                                    System.out.println(finalTuringMachine.getTapes().getTapes().get(finalI).getContents());
//                                    System.out.println("%%%%%%%%%%%%%");

                                }
                            }

                            @Override
                            public void onWrite(Character value) {

                            }
                        });
                    }
                    continue;
                }
                if (cnt == 1) {
                    String valuesTape = line.split(":")[1];

                    MultiTape<Character> multiTape = turingMachine.getTapes();

                    for (int i = 0; i < valuesTape.length(); i++)
                        multiTape.getTapes().get(index).move(Direction.RIGHT);
                    for (int i = 0; i < valuesTape.length(); i++)
                        multiTape.getTapes().get(index).move(Direction.LEFT);
                    for (int i = 0; i < valuesTape.length(); i++) {
                        multiTape.getTapes().get(index).write(valuesTape.charAt(i));
                        if (i == valuesTape.length() - 1)
                            break;
                        multiTape.getTapes().get(index).move(Direction.RIGHT);
                    }
                    for (int i = 0; i < valuesTape.length(); i++)
                        multiTape.getTapes().get(index).move(Direction.LEFT);
                    index++;
                    if (index == tapeCount)
                        cnt++;
                    continue;
                }
                if (cnt == 2) {
                    String[] states = line.split(",");
                    for (String state : states)
                        turingMachine.addState(state.trim());
                    cnt++;
                    continue;
                }
                if (cnt == 3) {
                    turingMachine.setCurrentState(line.trim());
                    cnt++;
                    continue;
                }
                if (cnt == 4) {
                    String[] states = line.split(",");
                    for (String state : states) {
                        turingMachine.getState(state).setAccepted(true);
                    }
                    cnt++;
                    continue;
                }
                String start = line.split("->")[0];
                String startState = start.split(",")[0].trim();
                String inputChar = start.split(",")[1].trim();

                MultiTapeReadWriteData<Character> inputMulti = new MultiTapeReadWriteData<>(inputChar.length());
                for (int i = 0; i < inputMulti.getLength(); i++) {
                    inputMulti.set(i, inputChar.charAt(i));
                }
                String target = line.split("->")[1];
                String targetState = target.split(",")[0].trim();
                String outputChar = target.split(",")[1].trim();
                MultiTapeReadWriteData<Character> outputMulti = new MultiTapeReadWriteData<>(outputChar.length());
                for (int i = 0; i < outputMulti.getLength(); i++) {
                    outputMulti.set(i, outputChar.charAt(i));
                }
                String dir = target.split(",")[2].trim();
                Direction[] directions = new Direction[dir.length()];
                for (int i = 0; i < directions.length; i++) {
                    Direction direction = switch (dir.charAt(i)) {
                        case 'R' -> Direction.RIGHT;
                        case 'L' -> Direction.LEFT;
                        default -> Direction.NON;
                    };
                    directions[i] = direction;
                }

                TuringTransitionOutput<Character> turingTransitionOutput = new TuringTransitionOutput<>(outputMulti, directions);
                turingMachine.addTransition(startState, inputMulti, targetState, turingTransitionOutput);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return turingMachine;
    }

    public static TuringMachine<Character> read(Reader input) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int data;
            while ((data = input.read()) != -1) {
                byteArrayOutputStream.write(data);
            }
            return read(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
//        File initialFile = new File("examples/tm_double_ones.txt");
        File initialFile = new File("examples/tm_counting_sort.txt");
        InputStream input = new FileInputStream(initialFile);
        TuringMachine<Character> turingMachine = read(input);
        turingMachine.run();

    }
}
