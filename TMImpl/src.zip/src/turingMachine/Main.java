package turingMachine;

/**
 * Created on 6/29/17.
 */
public class Main {
    public static void main(String[] args) {
        turingMachine.fxgui.GUI.main(args);
    }
}
