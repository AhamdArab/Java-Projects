package turingMachine.tape;

public enum Direction {
    LEFT,
    RIGHT,
    NON;
}
