package jpp.numbergame.gui;

public class PlayerScore {
    String name;
    int points;

    public PlayerScore(String name, int points) {
        this.name = name;
        this.points = points;
    }
}
