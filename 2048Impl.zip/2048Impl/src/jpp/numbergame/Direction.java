package jpp.numbergame;

public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
